# Flare
A mod for SourceMod that contains commands that are used to spawn/manipulate entities.
# Commands
Commands Are Listed Below:
#Admin Commands:
sm_explosion
#Player Commands:
sm_spawn, sm_delete (sm_del), sm_freezeprop, sm_unfreezeprop, sm_rotate (sm_flip, sm_r, sm_roll), sm_straight (sm_stand), sm_stack, sm_save, sm_load, sm_color, sm_door, sm_smove, sm_alpha (sm_amt), sm_axis, sm_ladder, sm_internet, sm_seturl, sm_light, sm_npc, sm_clear, sm_deleteall, sm_moveto, sm_skin, sm_owner, sm_balance, sm_fly, sm_msg, sm_reply, sm_count, sm_renderfx
# Disclaimer
I don't know how many updates this mod will get or for how long I'll be doing this mod, but feel free to fork this mod and modify it to suit your own purpose... If you fork this then start asking me to make private features for you, I will not. I will only mantian the features put into the base mod.
# Supported Games
Half-Life 2: Deathmatch
# Credits
FusionLock - Created/Coding the mod.
